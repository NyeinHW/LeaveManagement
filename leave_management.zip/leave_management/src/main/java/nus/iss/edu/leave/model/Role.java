package nus.iss.edu.leave.model;

public enum Role {
	STAFF,MANAGER,ADMIN

}
