package nus.iss.edu.leave.service;

public class AdminServiceImpl implements AdminService {

}
