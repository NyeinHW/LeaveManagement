//package nus.iss.edu.leave.service;
//
//import nus.iss.edu.leave.model.Admin;
//
//public interface AdminService {
//
//	public Admin findAdminByUsername(String username); 
//}
