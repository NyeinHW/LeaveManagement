package nus.iss.edu.leave.service;

public interface AdminService {

}
