package nus.iss.edu.leave.model;

public enum LeaveType {
	ANNUAL,MEDICAL,COMPENSATION
}
