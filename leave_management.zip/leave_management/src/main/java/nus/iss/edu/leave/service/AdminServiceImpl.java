//package nus.iss.edu.leave.service;
//
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import nus.iss.edu.leave.model.Admin;
//import nus.iss.edu.leave.repo.AdminRepository;
//
//public class AdminServiceImpl implements AdminService {
//
//	@Autowired
//	AdminRepository arepo;
//	
//	@Override
//	public Admin findAdminByUsername(String username) {		
//		Optional<Admin> a = arepo.findByUsername(username);
//		if (a != null) return a.get();
//		else return new Admin();
//	}
//
//}
