package nus.iss.edu.leave.controller;

public class ManagerController extends EmployeeController {

}
