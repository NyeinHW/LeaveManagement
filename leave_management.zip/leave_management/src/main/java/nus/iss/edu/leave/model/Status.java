package nus.iss.edu.leave.model;

public enum Status {
	APPLIED,UPDATED,DELETED,CANCELLED,APPROVED,REJECTED
}
