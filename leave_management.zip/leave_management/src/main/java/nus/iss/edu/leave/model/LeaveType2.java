//package nus.iss.edu.leave.model;
//
//public enum LeaveType2 {
//	ANNUAL,MEDICAL,COMPENSATION
//}
